# Kustomize FNs

This directory contains configurations for kustomize/kpt functions
that are intended to be applied with kpt.